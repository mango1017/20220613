# Android元件（CountDownTimer）– 倒數計時、ProgressBar、CountDownTimer整合 
demo 

Blog:http://nikeru8.blogspot.tw/2017/09/androidcountdowntimer.html
